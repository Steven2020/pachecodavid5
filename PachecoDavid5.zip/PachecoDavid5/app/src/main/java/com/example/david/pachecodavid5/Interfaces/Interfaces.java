package com.example.david.pachecodavid5.Interfaces;

import com.example.david.pachecodavid5.fragmento.frg_buscar;

public interface Interfaces extends frg_buscar.OnFragmentInteractionListener {
}
