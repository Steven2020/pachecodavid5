package com.example.david.pachecodavid5.adaptador;

import android.content.Context;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.TextView;

import com.example.david.pachecodavid5.R;
import com.example.david.pachecodavid5.modelo.Vino;

import java.util.List;

public class adaptervino extends BaseAdapter {
    private Context context;
    private List<Vino> listvino;

    public adaptervino(Context context, List<Vino> listvino) {
        this.context = context;
        this.listvino = listvino;
    }

    public Context getContext() {
        return context;
    }

    public void setContext(Context context) {
        this.context = context;
    }

    public List<Vino> getListWine() {
        return listvino;
    }

    public void setListWine(List<Vino> listaWine) {
        this.listvino = listaWine;
    }

    @Override
    public int getCount() {
        return 0;
    }

    @Override
    public Object getItem(int position) {
        return null;
    }

    @Override
    public long getItemId(int position) {
        return 0;
    }

    @Override
    public View getView(int position, View convertView, ViewGroup parent) {
        if(convertView ==null)
            convertView = View.inflate(context, R.layout.displayvino,null);
        TextView cajaid = (TextView) convertView.findViewById(R.id.lblid);
        TextView cajanom = (TextView) convertView.findViewById(R.id.lblnombre);
        TextView cajaaño = (TextView) convertView.findViewById(R.id.lblaño);
        TextView cajauva = (TextView) convertView.findViewById(R.id.lbluva);
        TextView cajapais = (TextView) convertView.findViewById(R.id.lblpais);
        TextView cajaregion = (TextView) convertView.findViewById(R.id.lblregion);
        TextView cajadescripcion = (TextView) convertView.findViewById(R.id.lbldescripcion);
        TextView cajaimagen = (TextView) convertView.findViewById(R.id.lblimagen);
        Vino wine = listvino.get(position);

        cajaid.setText(String.valueOf(wine.getId()));
        cajanom.setText(wine.getNombre());
        cajaaño.setText(String.valueOf(wine.getAño()));
        cajauva.setText(wine.getUvas());
        cajapais.setText(wine.getPais());
        cajaregion.setText(wine.getRegion());
        cajadescripcion.setText(wine.getDescripcion());
        cajaimagen.setText(wine.getImagen());

        return convertView;
    }
}
